"use client";
import { useState } from "react";

type Product = { id: number; title: string; brand: string; image: string; url: string };

const heroImages = [
  { src: "/images/hero-1.png", alt: "Woman in an emerald satin halter-neck backless evening gown with a front slit", tag: "Evening Gowns" },
  { src: "/images/hero-2.png", alt: "Woman in a crochet beach cover-up and straw hat", tag: "Beachwear" },
  { src: "/images/hero-3.png", alt: "Woman in a red sequin party dress on a rooftop", tag: "Party Ready" },
];

const bodyTypes = [
  { name: "Hourglass", img: "/images/body-hourglass.png", tip: "Defined waist", alt: "Hourglass-figure woman in a black wrap dress" },
  { name: "Pear", img: "/images/body-pear.png", tip: "Fuller hips", alt: "Pear-shaped woman in a fitted blue striped shirt with rolled sleeves, tan trousers, thin white belt and black strappy heels" },
  { name: "Apple", img: "/images/body-apple.png", tip: "Fuller midsection", alt: "Apple-shaped woman in a white peplum top and long white tailored trousers" },
  { name: "Rectangle", img: "/images/body-rectangle.png", tip: "Straight frame", alt: "Straight-frame woman in a camel blazer, crop top and jeans" },
  { name: "Curvy", img: "/images/body-curvy.png", tip: "All the curves", alt: "Curvy woman in a pink bodycon party dress" },
  { name: "Petite", img: "/images/body-petite.png", tip: "Under 5'4\"", alt: "Petite woman in a short bright red spaghetti-strap dress that flares from the waist" },
  { name: "Tall", img: "/images/body-tall.png", tip: "Long frame", alt: "Tall woman in a navy tailored pantsuit" },
  { name: "Plus Size", img: "/images/body-plus-size.png", tip: "Size 16+", alt: "Plus-size woman in a printed swimsuit and kimono cover-up" },
];

const occasions = ["Corporate", "Date Night", "Wedding Guest", "Casual", "Party", "Brunch", "Vacation", "Gym"];

const PRODUCTS: Record<string, Record<string, Product[]>> = {
  Hourglass: {
    Corporate: [
      { id: 1, title: "High-Waisted Tailored Trousers", brand: "Zara", image: "https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?w=500", url: "https://www.zara.com" },
      { id: 2, title: "Check High-Neck Top - Peplum Corporate Look", brand: "Zara", image: "https://i.postimg.cc/G2gzqd8H/IMG-9198.jpg", url: "https://www.zara.com/ww/en/check-high-neck-top-p04764037.html?v1=593153843&v2=2635766" },
    ],
  },
};

const whatsappNumber = "2348089484402";

export default function Page() {
  const [body, setBody] = useState<string | null>(null);
  const [occasion, setOccasion] = useState<string | null>(null);
  const items = body && occasion ? PRODUCTS[body]?.[occasion] || PRODUCTS.Hourglass.Corporate : [];

  if (body && occasion) {
    const message = `Hi Daya! I'm ${body} and I need help with ${occasion} wear. I saw Daya Style and I'd love you to style me!`;
    const waLink = `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(message)}`;

    return (
      <div className="min-h-screen bg-[#faf7f2] text-[#1a1410]">
        <header className="flex justify-between items-center px-6 py-4 border-b border-[#1a1410]/10 text-[11px] tracking-widest uppercase">
          <span className="font-bold tracking-[0.25em]">DAYA STYLE</span>
          <button onClick={() => setOccasion(null)} className="opacity-60 hover:opacity-100 uppercase tracking-widest">
            ← Back
          </button>
        </header>
        <main className="px-6 py-10 max-w-6xl mx-auto">
          <p className="text-[10px] tracking-[0.2em] uppercase text-[#a0673b]">Curated for you</p>
          <h1 className="font-serif text-4xl md:text-5xl mt-2 text-balance">
            {occasion} <span className="italic font-light">for {body}</span>
          </h1>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mt-8">
            {items.map((p) => (
              <a key={p.id} href={p.url} target="_blank" rel="noopener noreferrer" className="group">
                <div className="aspect-[3/4] bg-[#efe7dc] rounded-2xl overflow-hidden">
                  <img src={p.image || "/placeholder.svg"} alt={p.title} className="w-full h-full object-cover group-hover:scale-105 transition duration-700" />
                </div>
                <p className="text-[10px] tracking-widest uppercase opacity-50 mt-3">{p.brand}</p>
                <p className="text-sm leading-snug mt-1">{p.title}</p>
                <p className="text-[11px] underline underline-offset-4 mt-2">Shop →</p>
              </a>
            ))}
          </div>

          <a
            href={waLink}
            target="_blank"
            rel="noopener noreferrer"
            className="mt-14 flex items-center justify-center gap-3 w-full bg-[#1a1410] text-[#faf7f2] py-5 rounded-full text-xs tracking-[0.15em] uppercase font-medium hover:bg-[#a0673b] transition"
          >
            Still unsure on what fits? Chat with Daya on WhatsApp
          </a>
          <p className="text-center text-[11px] opacity-50 mt-3">Personal styling for ₦7,500 — 15 min session</p>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#faf7f2] text-[#1a1410]">
      <header className="flex justify-between items-center px-6 py-4 text-[11px] tracking-widest uppercase max-w-6xl mx-auto">
        <span className="font-bold tracking-[0.25em]">DAYA STYLE</span>
        <span className="opacity-50">Lagos • Est 2025</span>
      </header>

      <main className="px-6 max-w-6xl mx-auto pb-24">
        <section aria-label="Featured looks" className="grid grid-cols-3 gap-2 md:gap-3 mt-2">
          {heroImages.map((img) => (
            <div key={img.src} className="relative aspect-[3/4] md:aspect-[2/3] overflow-hidden rounded-2xl md:rounded-3xl bg-[#efe7dc]">
              <img src={img.src || "/placeholder.svg"} alt={img.alt} className="w-full h-full object-cover" />
              <span className="absolute bottom-3 left-3 bg-[#faf7f2] text-[#1a1410] px-3 py-1 rounded-full text-[9px] md:text-[10px] tracking-widest uppercase">
                {img.tag}
              </span>
            </div>
          ))}
        </section>

        <section className="mt-10 md:mt-14 flex flex-col md:flex-row md:items-end md:justify-between gap-4">
          <h1 className="font-serif text-5xl md:text-7xl leading-[0.95] tracking-tight text-balance">
            Every body is
            <br />
            <span className="italic font-light text-[#a0673b]">Daya body.</span>
          </h1>
          <p className="text-sm opacity-70 max-w-sm leading-relaxed">
            {"Gowns, beachwear, date looks, modest dresses, tailoring and more. We style every woman, every shape, every occasion."}
          </p>
        </section>

        <section aria-labelledby="step-1" className="mt-14">
          <div className="flex items-baseline justify-between border-b border-[#1a1410]/10 pb-3 mb-5">
            <h2 id="step-1" className="text-[11px] tracking-[0.2em] uppercase">
              <span className="text-[#a0673b]">01</span> — Choose your body type
            </h2>
            <span className="text-[10px] opacity-40 uppercase tracking-widest hidden md:inline">Tap a card</span>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4">
            {bodyTypes.map((t) => {
              const active = body === t.name;
              return (
                <button
                  key={t.name}
                  onClick={() => {
                    setBody(t.name);
                    setOccasion(null);
                  }}
                  aria-pressed={active}
                  className={`group relative text-left rounded-2xl overflow-hidden aspect-[4/5] bg-[#efe7dc] transition ${
                    active ? "ring-2 ring-offset-2 ring-offset-[#faf7f2] ring-[#a0673b]" : ""
                  }`}
                >
                  <img src={t.img || "/placeholder.svg"} alt={t.alt} className="w-full h-full object-cover group-hover:scale-105 transition duration-700" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/10 to-transparent" />
                  <div className="absolute bottom-0 left-0 right-0 p-3 md:p-4 text-white">
                    <p className="font-serif text-xl md:text-2xl">{t.name}</p>
                    <p className="text-[10px] tracking-widest uppercase opacity-80 mt-0.5">{t.tip}</p>
                  </div>
                  {active && (
                    <span className="absolute top-3 right-3 bg-[#a0673b] text-white text-[9px] tracking-widest uppercase px-2 py-1 rounded-full">
                      Selected
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </section>

        {body && (
          <section aria-labelledby="step-2" className="mt-14">
            <div className="border-b border-[#1a1410]/10 pb-3 mb-5">
              <h2 id="step-2" className="text-[11px] tracking-[0.2em] uppercase">
                <span className="text-[#a0673b]">02</span> — Occasion for {body}
              </h2>
            </div>
            <div className="flex flex-wrap gap-2">
              {occasions.map((o) => (
                <button
                  key={o}
                  onClick={() => setOccasion(o)}
                  className="px-5 py-3 text-[11px] tracking-wide uppercase border border-[#1a1410]/20 rounded-full hover:bg-[#1a1410] hover:text-[#faf7f2] transition"
                >
                  {o}
                </button>
              ))}
            </div>
          </section>
        )}
      </main>
    </div>
  );
}
